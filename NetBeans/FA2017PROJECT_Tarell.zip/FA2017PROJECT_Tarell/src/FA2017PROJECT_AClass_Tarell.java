/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ztare
 */
public class FA2017PROJECT_AClass_Tarell {
    
    private String className;
    private String grade;
    
    public FA2017PROJECT_AClass_Tarell(String cName, String g) {
        
        this.className = cName;
        this.grade = g;
    }
    
    public void setClass(String className, String grade) {
    
        this.className = className;
        this.grade = grade;
    }
    
    public String toString() {
        String s = className + " - " + grade;
        return s;
    }
}
