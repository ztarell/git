/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.*;
/**
 *
 * @author ztare
 */
public class FA2017PROJECT_Student_Tarell {
    private String id;
    private String lastname;
    private String firstname;
    private String ssn;
    private String dob;
    private String phone;
    private String address;
    private String className;
    private String grade;
    
    private ArrayList classList;
    
    
    
    public FA2017PROJECT_Student_Tarell(String i, String l,String f, String s, String d, String p, String a) {
        id = i;
        lastname = l;
        firstname = f;
        ssn = s;
        dob = d;
        phone = p;
        address = a;
        
    }
    
    public FA2017PROJECT_Student_Tarell deepCopy() {
        FA2017PROJECT_Student_Tarell clone = new FA2017PROJECT_Student_Tarell(id, lastname, firstname, ssn, dob, phone, address);
                return clone;
    }
    
    public String getKey() {
        return id;
    }
    
    public int compareTo(String targetKey) {
        return(id.compareTo(targetKey));
    }
    
    public String toString () {
        String str = "";
        for (int i = 0; i < classList.size(); i++) {
            str = str + classList.get(i) + "\n";
        }
        String s = "\nStudent:\t" + firstname + " " + lastname
                + "\nStudent ID:\t" + id
                + "\nSS Number:\t" + ssn
                + "\nBirthday:\t" + dob
                + "\nPhone:\t\t" + phone
                + "\nAddress:\t" + address
                + "\nClasses:\n" + str;
        
        return s;
    }
    
    public void setClassList(ArrayList classList) {
        this.classList = classList;
    }
}
